
public class Program {

	public static void main(String[] args) {
		Stack s = new Stack();
		for (int i = 0; i < 50; ++i) {
			s.push(i);
			System.out.println(s);
		}

	}

}
